<?php


Route::get('/','DownloadController@downfunc');